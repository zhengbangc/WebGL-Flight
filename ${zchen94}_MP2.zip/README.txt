Zhengbang Chen zchen94
MP2 for CS418 class @ University of Illinois at Urbana-Champaign

Instruction to play the game: 
same as the instructions that you will see in the html page
1. pitch the plane by “w” and “s” key
2. roll the plane by “a” and “d” key
3. yaw the plane by “q” and “e” key
4. change the speed of the plane by “+” and “-“ key